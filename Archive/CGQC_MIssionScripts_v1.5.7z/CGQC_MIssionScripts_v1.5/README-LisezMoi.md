# CGQC_MissionScripts
Ouvrez le fichier: 	
---------------------
-- description.ext --
---------------------

Pour setter tout vous trucs!